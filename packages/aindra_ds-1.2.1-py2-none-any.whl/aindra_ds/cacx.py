import os

SLIDE_TYPE_PAP_CONV = 0
SLIDE_TYPE_PAP_LBC = 1
SLIDE_TYPE_PAP_HISTO = 2
SLIDE_TYPE_PAP_HAEMA = 3


# slide_rescanned name change and remaining changes will do next release
class Slide:

    def __init__(self, slide_dir, slide_type, tile_dir, diagnosis=None, slide_rescanned=0, case_keys=None,
                 pyramid_dir=None, seg_annot_file=None, slide_file=None):
        self.__slide_dir = slide_dir
        self.slide_type = slide_type
        self.__tile_dir = tile_dir

        if slide_file is None:
            self.__slide_file = os.path.join(slide_dir, "info.txt")
        else:
            self.__slide_file = slide_file

        if pyramid_dir is None:
            self.pyramid_dir = os.path.join(slide_dir, "pyramid")
        else:
            self.pyramid_dir = pyramid_dir

        if seg_annot_file is None:
            self.__seg_annot_file = os.path.join(slide_dir, "annot.txt")
        else:
            self.__seg_annot_file = seg_annot_file

        self.__diagnosis = diagnosis
        self.slide_rescanned = slide_rescanned
        self.case_keys = case_keys

    @property
    def slide_dir(self):
        if not os.path.exists(self.__slide_dir):
            os.makedirs(self.__slide_dir)
        return self.__slide_dir

    @property
    def tile_dir(self):
        if not os.path.exists(self.__tile_dir):
            try:
                os.makedirs(self.__tile_dir)

            except OSError, e:
                if e.errno != os.errno.EEXIST:
                    raise
                    # time.sleep might help here
                pass

        return self.__tile_dir

    @property
    def seg_annot_file(self):
        return self.__seg_annot_file

    @property
    def uid(self):
        return self.case_keys

    def serializable_attrs(self):
        return (dict(
            (i.replace(self.__class__.__name__, '').lstrip("_"), value)
            for i, value in self.__dict__.items()
        ))

    @classmethod
    def from_json(cls, data):
        return cls(**data)
