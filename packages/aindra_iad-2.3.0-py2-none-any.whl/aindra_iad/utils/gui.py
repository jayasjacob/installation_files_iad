import cv2
import matplotlib.pyplot as plt
from matplotlib.widgets import RectangleSelector


def get_map_roi(map_path):

    roi = [None]
    def line_select_callback(eclick, erelease):

        x1, y1 = eclick.xdata, eclick.ydata
        x2, y2 = erelease.xdata, erelease.ydata
        roi[0] = [x1, y1, x2, y2]

    def toggle_selector(event):
        if event.key in ['Q', 'q'] and toggle_selector.RS.active:
            toggle_selector.RS.set_active(False)

        if event.key in ['A', 'a'] and not toggle_selector.RS.active:
            toggle_selector.RS.set_active(True)

    img = cv2.imread(map_path)
    fig, current_ax = plt.subplots()
    plt.imshow(img)

    toggle_selector.RS = RectangleSelector(current_ax, line_select_callback,
                                           drawtype='box', useblit=True,
                                           button=[1, 3],  # don't use middle button
                                           minspanx=5, minspany=5,
                                           spancoords='data',
                                           interactive=True)
    plt.connect('key_press_event', toggle_selector)
    current_ax.get_xaxis().set_visible(False)
    current_ax.get_yaxis().set_visible(False)
    plt.show()

    return roi[-1]