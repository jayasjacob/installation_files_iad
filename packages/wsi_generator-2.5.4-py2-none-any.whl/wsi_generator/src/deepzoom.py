import os
import time
import shutil
import multiprocessing

import cv2
import json
import cPickle
import itertools
import numpy as np
import tensorflow as tf
from datetime import datetime
from multiprocessing import Process, Pool, Lock, Queue

import blending
import registration as reg


class BlendImgError(RuntimeError):
    pass


def chunks(src_imgs, n):
    for i in range(0, len(src_imgs), n):
        yield src_imgs[i:i+n]


def save_mean_corr_img(img_path, mean_img):
    for img_path in img_path:
        src_img_path, tgt_img_path = img_path
        img = cv2.imread(src_img_path)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        corr_img = np.asarray(img, dtype=np.float)

        corr_img[:, :, 2] = np.multiply(corr_img[:, :, 2], mean_img)
        corr_img[corr_img > 254] = 254
        corr_img = np.asarray(corr_img, dtype=np.uint8)
        corr_img = cv2.cvtColor(corr_img, cv2.COLOR_HSV2BGR)

        gamma = 1.2
        lookUpTable = np.empty((1, 256), np.uint8)
        for i in range(256):
            lookUpTable[0, i] = np.clip(pow(i / 255.0, gamma) * 255.0, 0, 255)
        corr_img = cv2.LUT(corr_img, lookUpTable)

        corr_img = cv2.convertScaleAbs(corr_img, alpha=1.15, beta=0)

        if not os.path.exists(tgt_img_path):
            cv2.imwrite(tgt_img_path, corr_img)


def mean_corr(a_b):
    return save_mean_corr_img(*a_b)


def calc_mean_img(imgs):

    img_size = np.shape(cv2.imread(imgs[0]))

    imgs_sum = np.zeros((img_size[0], img_size[1]), dtype=np.float)

    for src_image in imgs:
        img = cv2.imread(src_image)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        imgs_sum = np.add(imgs_sum, img[:, :, 2])

    mean_img = imgs_sum / len(imgs)
    mean_val = cv2.mean(mean_img)
    gain_coeff = mean_val[0] / mean_img
    return gain_coeff


def correct_mean(src_path, tgt_tiles_dir):
    src_images = os.listdir(src_path)
    src_imgs = list()
    src_tgt_pair = list()

    for src_image in src_images:
        if '.jpg' in src_image:
            src_imgs.append(os.path.join(src_path, src_image))
            src_tgt_pair.append((os.path.join(src_path, src_image), os.path.join(tgt_tiles_dir, src_image)))

    n_cores = multiprocessing.cpu_count()/2
    chunk_size = len(src_imgs) / n_cores
    src_sub_lists = list(chunks(src_imgs, chunk_size))
    src_tgt_sub_lists = list(chunks(src_tgt_pair, chunk_size))

    worker_pool = Pool(n_cores)

    result = worker_pool.map(calc_mean_img, src_sub_lists)
    gain_coeff = np.mean(result, axis=0)

    worker_pool.map(mean_corr, itertools.izip(src_tgt_sub_lists, itertools.repeat(gain_coeff)))
    worker_pool.close()
    worker_pool.join()


def create_tx_pairs(src_path):
    c_max = 0
    r_max = 0
    file_dict = dict()
    src_images = os.listdir(src_path)
    for src_image in src_images:
        if '.jpg' in src_image:
            name, ext = src_image.split(".")
            _, c, r, _ = name.split("_")
            c, r = int(c), int(r)
            c_max = max(c_max, c)
            r_max = max(r_max, r)
            file_dict['{}_{}'.format(c, r)] = src_image
    img = cv2.imread(os.path.join(src_path, file_dict['{}_{}'.format(c_max, r_max)]))
    c_max = c_max + 1
    r_max = r_max + 1

    tx_triplets = list()
    horizontal_tx_pairs = list()
    vertical_tx_pairs = list()
    for src_image in src_images:
        if '.jpg' in src_image:
            name, ext = src_image.split(".")
            _, c, r, _ = name.split("_")
            c, r = int(c), int(r)

            central_image = os.path.join(src_path, file_dict['{}_{}'.format(c, r)])
            # Need to check for neighbour images which have overlap
            # Top and left overlapping images are paired with center image
            # Need to check for odd and even row to check the overlapping pattern, top left is origin
            if r % 2 == 0 and '{}_{}'.format(c + 1, r) in file_dict:
                left_image = os.path.join(src_path, file_dict['{}_{}'.format(c + 1, r)])
            elif r % 2 != 0 and '{}_{}'.format(c - 1, r) in file_dict:
                left_image = os.path.join(src_path, file_dict['{}_{}'.format(c - 1, r)])
            else:
                left_image = ""

            if '{}_{}'.format(c_max - 1 - c, r + 1) in file_dict:
                top_image = os.path.join(src_path, file_dict['{}_{}'.format(c_max - 1 - c, r + 1)])
            else:
                top_image = ""

            if os.path.exists(left_image) and os.path.exists(top_image):
                tx_triplets.append([central_image, left_image, top_image])
            elif os.path.exists(left_image):
                horizontal_tx_pairs.append([central_image, left_image])
            elif os.path.exists(top_image):
                vertical_tx_pairs.append([central_image, top_image])

    return file_dict, (r_max, c_max), img.shape, tx_triplets, horizontal_tx_pairs, vertical_tx_pairs


def register(data_queue,
             triplet_files, horizontal_files, vertical_files,
             batch_size, pause_lock):

    tx_graph = reg.tx_est_graph(batch_size=batch_size)
    with tf.Session(graph=tx_graph) as sess:
        init = tx_graph.get_collection("init")
        sess.run(init)

        triplet_txs = reg.compute_triplet_txs(triplet_files, tx_graph, sess, pause_lock)
        horizontal_txs = reg.compute_horizontal_txs(horizontal_files, tx_graph, sess, pause_lock)
        vertical_txs = reg.compute_vertical_txs(vertical_files, tx_graph, sess, pause_lock)

        pair_translations = horizontal_txs + vertical_txs + triplet_txs
        with open('/tmp/pair_tx.pkl', 'wb') as f:
            cPickle.dump(pair_translations, f)
        data_queue.put('/tmp/pair_tx.pkl')

    sess.close()


def register_wrapper(triplet_files, horizontal_files, vertical_files, pause_lock=Lock(), num_threads=4, batch_size=4,
                     gpu_mem_fraction=0.3):
    """
    Computes pair wise translation between images in a folder
    The images are assumed to be named as {column}_{row}.webp
    The translations are returned in the argument pair_translations.
    pair_translations : [[current_image, reference image, horizontal tx, vertical tx, variance]...]
    """
    data_queue = Queue()
    worker = Process(target=register,
                     args=(data_queue,
                           triplet_files, horizontal_files, vertical_files,
                           batch_size, pause_lock))

    worker.start()
    worker.join()
    pair_tx_path = data_queue.get()
    with open(pair_tx_path, 'rb') as f:
        pair_translations = cPickle.load(f)
    return pair_translations


def blend_q_processor(logger, pause_lock, blend_list, dir_path, is_alpha_blending, scale, nworkers=1):

    aug_blend_queue = Queue()
    exception_queue = Queue()

    processed_cntr = 0
    while processed_cntr < len(blend_list):

        workers = list()
        for i in range(nworkers):
            worker = Process(target=blending.blend_worker, args=(aug_blend_queue, exception_queue))
            worker.start()
            workers.append(worker)

        for i in range(processed_cntr, len(blend_list)):
            blend_item = blend_list[i]

            while aug_blend_queue.qsize() > nworkers * 10:
                time.sleep(0.5)

            if pause_lock.acquire(blocking=False):
                aug_blend_queue.put((blend_item, dir_path, is_alpha_blending, scale))
                processed_cntr += 1
                pause_lock.release()
            else:
                break

        aug_blend_queue.put(None)
        for worker in workers:
            worker.join()
        aug_blend_queue.get()
        if not exception_queue.empty():
            failed_task = exception_queue.get()
            logger.error("Blend and save failed for {}".format(failed_task[1]))
            exception_queue = Queue()
            raise BlendImgError("Blend and save failed")


def generate_deepzoom_pyramid(global_positions, wsi_shape, tgt_path, logger, clog_file, tgt_tile_shape, overlap,
                              image_shape, pause_lock, nworkers=4, image_format='webp',
                              tmp_folder_prefix="__pyr_", pyramid_name="tiles"):

    logger.info("Creating c logger")
    blending.create_clogger(clog_file)
    logger.info("Created c logger")

    logger.info("Creating blend mask")
    blending.create_mask(image_shape[0], image_shape[1])
    logger.info("Created blend mask")

    # --------------------------------------------------------------------------------------------
    # Create the image pyramid in a folder called pyramid_name_files
    # ---------------------------------------------------------------------------------------------
    pyr_files_tgt_dir = os.path.join(tgt_path, pyramid_name + "_files")
    if os.path.exists(pyr_files_tgt_dir):
        shutil.rmtree(pyr_files_tgt_dir)
    os.makedirs(pyr_files_tgt_dir)

    pyramid_base_dir = os.path.join(pyr_files_tgt_dir, "_blend_base_1")
    try:
        os.makedirs(pyramid_base_dir)
    except os.error:
        pass

    with pause_lock:
        blend_list, wsi_pix_size = blending.compute_blending_grid(src_list=global_positions,
                                                                  tgt_tile_size=tgt_tile_shape,
                                                                  tgt_overlap=overlap)

    is_alpha_blending = True
    blend_q_processor(logger, pause_lock, blend_list, pyramid_base_dir, is_alpha_blending, 1.0, nworkers)

    next_layer_src = list()
    for blend_item in blend_list:

        tile_id, tile_pos, tile_size = blend_item[0:3]
        tile_path = os.path.join(pyramid_base_dir, '{}_{}.webp'.format(tile_id[1], tile_id[0]))
        next_layer_src.append([tile_path, tile_pos, tile_size])
    logger.info("Base pyramid directory created")
    level_list = [pyramid_base_dir]

    while True:

        level_path = os.path.join(pyr_files_tgt_dir, "_pyr_" + str(len(level_list)))
        logger.debug("Creating pyramid directory " + level_path)
        try:
            os.makedirs(level_path)
        except os.error:
            pass

        blend_list, wsi_size = blending.compute_blending_grid(next_layer_src,
                                                              tgt_tile_size=(tgt_tile_shape[0]*2, tgt_tile_shape[1]*2),
                                                              tgt_overlap=overlap*2)
        is_alpha_blending = False
        blend_q_processor(logger, pause_lock, blend_list, level_path, is_alpha_blending, 0.5, nworkers)

        level_list.append(level_path)
        if len(blend_list) == 1 and np.all(np.array(blend_list[0][2], dtype=int) < 4):
            break

        next_layer_src = list()
        for blend_item in blend_list:

            tile_id, tile_pos, tile_size = blend_item[0:3]
            tile_path = os.path.join(level_path, '{}_{}.webp'.format(tile_id[1], tile_id[0]))

            tile_size_dwn = np.asarray(tile_size, dtype=int)/2
            tile_pos_dwn = np.asarray(tile_pos, dtype=int)/2
            next_layer_src.append([tile_path, tile_pos_dwn, tile_size_dwn])

    # Rename the folders according to deep zoom
    level_list = level_list[::-1]
    for idx, level_item in enumerate(level_list):
        target_level_dir = os.path.join(pyr_files_tgt_dir, str(idx))
        os.rename(level_item, target_level_dir)

    logger.info("Creating dzi file")
    # Create the dzi file
    dzi_info = dict()
    dzi_info["Image"] = dict()
    dzi_info["Image"]["xmlns"] = "http://schemas.microsoft.com/deepzoom/2008"
    dzi_info["Image"]["Format"] = "webp"
    dzi_info["Image"]["Overlap"] = str(int(overlap))
    dzi_info["Image"]["TileSize"] = str(int(tgt_tile_shape[0]))
    dzi_info["Image"]["Size"] = dict()
    dzi_info["Image"]["Size"]["Height"] = str(int(wsi_pix_size[0]))
    dzi_info["Image"]["Size"]["Width"] = str(int(wsi_pix_size[1]))

    dzi_path = os.path.join(tgt_path, pyramid_name + '.dzi')
    with open(dzi_path, 'w') as fp:
        json.dump(dzi_info, fp, indent=4)

    blending.remove_clogger()
    logger.info("C logger removed")
