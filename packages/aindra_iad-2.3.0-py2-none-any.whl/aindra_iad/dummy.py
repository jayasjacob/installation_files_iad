import os
import time
import ctypes
from threading import Thread
from shutil import copyfile
import serial.tools.list_ports

from aindra_ds import cacx


class Iad:

    def __init__(self, logger):

        self.logger = logger

        self.__iad_instance = ctypes.c_void_p()
        self.__status = ctypes.c_float()
        self.__signal = ctypes.c_int()
        self.__exceptions = ctypes.c_int()

        my_path = os.path.abspath(os.path.dirname(__file__))

        lib_path = os.path.join(my_path, "native/bin/libiad_10.so")
        logger.info("Loading native library at {}".format(lib_path))
        self.__iad_lib = ctypes.cdll.LoadLibrary(lib_path)

        logger.info("Scanning serial ports")
        ports = list(serial.tools.list_ports.comports())

        self.__imaging_thread = None

    def __del__(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        return True

    def __image(self, tgt_dir, imaging_mode, log_file):

        if imaging_mode == cacx.SLIDE_TYPE_PAP_HISTO:
            self.__start_image_async((2500, 300), (175, 64), (21, 31 ), cacx.SLIDE_TYPE_PAP_HISTO, tgt_dir, log_file)

        elif imaging_mode == cacx.SLIDE_TYPE_PAP_LBC:
            self.__start_image_async((2000, 200), (150, 64), (21, 31 ), cacx.SLIDE_TYPE_PAP_LBC, tgt_dir, log_file)

        else:
            raise NotImplementedError("The imaging mode {} is not supported".format(imaging_mode))

    def __start_image_async(self, origin, grid, fov, imaging_mode, tgt_dir, log_file):

        self.__status.value = 0
        self.__signal.value = 0
        self.__exceptions.value = 0

        b_tgt_dir = tgt_dir.encode('utf-8')
        i_img_mode = ctypes.c_int()
        i_img_mode.value = imaging_mode

        self.logger.info("Staring async imaging to {}".format(tgt_dir))

        my_path = os.path.abspath(os.path.dirname(__file__))
        src_img = os.path.join(my_path, "data/dummy.jpg")

        self.__progress = 0
        self.__max_progress = 100
        time.sleep(5)
        for i in range(10):
            for j in range(10):
                time.sleep(1)
                copyfile(src_img, os.path.join(tgt_dir, "{:06d}_{}_{}.jpg".format(i*10 + j, i, j)))
                self.__progress += 1

    def image(self, tgt_dir, imaging_mode, log_file):
        self.__imaging_thread = Thread(target=self.__image, args=(tgt_dir, imaging_mode, log_file))
        self.__imaging_thread.start()

    def join(self):
        self.__imaging_thread.join()

    def joinable(self):
        if self.__imaging_thread.is_alive():
            return True
        else:
            return False

    def get_status(self):
        return self.__progress, self.__max_progress



