# code for estimating global tx using optimisation
import os
import multiprocessing
import numpy as np
import shutil
from sklearn.preprocessing import MinMaxScaler
import statsmodels.api as sm

import deepzoom


def optimize_coordinates(pair_translations, c_max, r_max, image_shape):
    row_eqn = np.zeros((len(pair_translations), c_max * r_max), dtype=np.float32)
    row_txs = np.zeros(len(pair_translations), dtype=np.float32)
    weights_row = np.zeros(len(pair_translations), dtype=np.float32)

    col_eqn = np.zeros((len(pair_translations), c_max * r_max), dtype=np.float32)
    col_txs = np.zeros(len(pair_translations), dtype=np.float32)
    weights_col = np.zeros(len(pair_translations), dtype=np.float32)

    img_dict = dict()

    eq_no_row = 0
    eq_no_col = 0

    avg_vr_tx = 0
    avg_hr_tx = 0

    for line in pair_translations:

        file1, file2, tx_row, tx_col, est_var = line
        _, c_ref, r_ref, _ = file1.split('/')[-1].split(".")[0].split("_")
        c_ref, r_ref = int(c_ref), int(r_ref)
        if '{}_{}'.format(c_ref, r_ref) not in img_dict:
            img_dict['{}_{}'.format(c_ref, r_ref)] = [file1]
        _, c_rel, r_rel, _ = file2.split('/')[-1].split(".")[0].split("_")
        c_rel, r_rel = int(c_rel), int(r_rel)
        if '{}_{}'.format(c_rel, r_rel) not in img_dict:
            img_dict['{}_{}'.format(c_rel, r_rel)] = [file2]

        # Since image has a 90 degree rot wrt to movement tx_col of image is tx_row here
        # Since image and WSI has a flip

        if abs(r_rel - r_ref) == 1:
            tx_img_col = -(400 - tx_col) if tx_col > 0 else tx_col

            if tx_col == 0:
                tx_img_col = avg_hr_tx
            avg_hr_tx = tx_img_col if avg_hr_tx == 0 else (avg_hr_tx + tx_img_col) / 2
            row_eqn[eq_no_row, r_ref * c_max + c_ref] = -1.0
            row_eqn[eq_no_row, r_rel * c_max + c_rel] = 1.0

            row_txs[eq_no_row] = (image_shape[1] + tx_img_col)
            weights_row[eq_no_row] = est_var
            eq_no_row += 1

            col_eqn[eq_no_col, r_ref * c_max + c_ref] = -1.0
            col_eqn[eq_no_col, r_rel * c_max + c_rel] = 1.0

            col_txs[eq_no_col] = tx_row
            weights_col[eq_no_col] = est_var
            eq_no_col += 1

        elif abs(c_rel - c_ref) == 1:
            tx_img_row = -(400 - tx_row) if tx_row > 0 else tx_row

            if tx_row == 0:
                tx_img_row = avg_vr_tx
            avg_vr_tx = tx_img_row if avg_vr_tx == 0 else (avg_vr_tx + tx_img_row) / 2

            col_eqn[eq_no_col, r_ref * c_max + c_ref] = -1.0
            col_eqn[eq_no_col, r_rel * c_max + c_rel] = 1.0

            col_txs[eq_no_col] = (image_shape[0] + tx_img_row)
            weights_col[eq_no_col] = est_var
            eq_no_col += 1

            row_eqn[eq_no_row, r_ref * c_max + c_ref] = -1.0
            row_eqn[eq_no_row, r_rel * c_max + c_rel] = 1.0

            row_txs[eq_no_row] = tx_col
            weights_row[eq_no_row] = est_var
            eq_no_row += 1
        else:
            raise AssertionError

    mod_wls = sm.WLS(row_txs, row_eqn, weights=weights_row)
    res = mod_wls.fit()
    x = res.params
    scaler = MinMaxScaler(feature_range=(0, abs(min(x)) + abs(max(x))))
    x = np.reshape(x, (x.shape[0], 1))
    tx_hr = scaler.fit_transform(x)

    mod_wls = sm.WLS(col_txs, col_eqn, weights=weights_col)
    res = mod_wls.fit()
    x = res.params
    scaler = MinMaxScaler(feature_range=(0, abs(min(x)) + abs(max(x))))
    x = np.reshape(x, (x.shape[0], 1))
    tx_vr = scaler.fit_transform(x)

    pair_translations = None

    glb_coord = np.zeros((r_max, c_max, 2), dtype=np.int)
    for r in range(r_max):
        for c in range(c_max):
            glb_coord[r, c, 0] = tx_hr[r * c_max + c, 0]
            glb_coord[r, c, 1] = tx_vr[r * c_max + c, 0]

    tx_vr = None
    tx_vr = None

    img_grid_list = list()
    for r in range(r_max):
        for c in range(c_max):
            y_pos = glb_coord[r, c, 0]
            x_pos = glb_coord[r, c, 1]
            if '{}_{}'.format(c, r) in img_dict:
                img_grid_list.append(
                    [img_dict['{}_{}'.format(c, r)][0], (int(x_pos), int(y_pos)), (image_shape[0], image_shape[1])])

    return img_grid_list


def stitch_slide(slide_dir, source_dir, pyramid_dir, logger, clog_file, pause_lock):
    with pause_lock:
        corrected_tile_dir = os.path.join(slide_dir, "processed_tiles", "tiles")
        if not os.path.exists(corrected_tile_dir):
            os.makedirs(corrected_tile_dir)
        deepzoom.correct_mean(source_dir, corrected_tile_dir)
        logger.info("Image preprocessing completed")

    with pause_lock:
        file_dict, wsi_shape, image_shape, tx_triplets, horizontal_tx_pairs, vertical_tx_pairs = \
            deepzoom.create_tx_pairs(corrected_tile_dir)

    with pause_lock:
        pair_translations = deepzoom.register_wrapper(tx_triplets, horizontal_tx_pairs, vertical_tx_pairs)

    logger.info("Registration on files in dir {} completed".format(corrected_tile_dir))
    logger.debug("Rows, Columns:{}, {}".format(wsi_shape[0], wsi_shape[1]))

    logger.info("Estimating global translation matrices")

    with pause_lock:
        img_grid_list = optimize_coordinates(pair_translations, wsi_shape[1], wsi_shape[0], image_shape)

    logger.info("Creating deepzoom pyramid")
    n_cpus = multiprocessing.cpu_count()
    logger.info("Creating seepzoom pyramid with {} cores ".format(n_cpus / 2))
    deepzoom.generate_deepzoom_pyramid(img_grid_list,
                                       wsi_shape,
                                       pyramid_dir, logger, clog_file, (960, 960), 1, image_shape, pause_lock,
                                       n_cpus / 2)

    shutil.rmtree(os.path.join(slide_dir, "processed_tiles"))
    logger.info("Processed tile directory removed")
