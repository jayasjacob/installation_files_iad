import multiprocessing as mp

class PriorityLock():

    def __init__(self):
        lock = mp.Lock()
        queue = mp.Queue()

    def acquire(self):

