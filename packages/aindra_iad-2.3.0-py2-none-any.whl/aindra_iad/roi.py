import os
import cv2
import numpy as np
import statsmodels.api as sm
from scipy import stats


def optimize_coordinates(pair_translations, c_max):
    col_eqn = np.zeros((len(pair_translations)+1, len(pair_translations)+1), dtype=np.float32)
    col_txs = np.zeros(len(pair_translations)+1, dtype=np.float32)
    weights_col = np.zeros(len(pair_translations)+1, dtype=np.float32)

    eq_no_col = 0
    for value in pair_translations:
        col_eqn[eq_no_col, eq_no_col] = -1.0
        col_eqn[eq_no_col, eq_no_col+1] = 1.0
        col_txs[eq_no_col] = value[0]
        weights_col[eq_no_col] = value[1]

        eq_no_col += 1

    mod_wls = sm.WLS(col_txs, col_eqn, weights=weights_col)
    res = mod_wls.fit()
    x = res.params

    return x


def register_tx(img1, img2):

    img1 = img1[:,70:100, :]
    img2 = img2[:,0:30, :]
    img1_g = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    img2_g = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    fft1 = np.fft.fft2(img1_g)
    fft2 = np.fft.fft2(img2_g)
    fc = fft1*np.conjugate(fft2)
    # eps = 1e-5
    # fc[fc == 0] = eps
    fcn = np.divide(fc, np.abs(fc))

    ncci = np.fft.ifft2(fc)
    ncci = abs(ncci)

    expand_ncci = ncci.ravel()
    pos_vec = np.argmax(expand_ncci)
    corr = np.max(expand_ncci)

    height, width = np.shape(img1_g)

    r_shift = pos_vec/width
    c_shift = pos_vec%width

    if r_shift > height/2:
        r_shift = height - r_shift

    # Check for right column is having up/down shift relative to left column

    corr_coef_col_upshift = abs(stats.pearsonr(img1[0:height-r_shift, :, :].ravel(), img2[r_shift:height, :, :].ravel())[0])
    corr_coef_col_downshift = abs(stats.pearsonr(img1[r_shift:height, :, :].ravel(), img2[0:height-r_shift, :, :].ravel())[0])

    if corr_coef_col_upshift > corr_coef_col_downshift:
        r_shift *= -1

    return r_shift, c_shift, corr


def create_unaligned_wsi(roi_img_dir):
    r_max = 0
    c_max = 0

    for item in os.listdir(roi_img_dir):
        img_name = item.split('.')
        c, r = img_name[0].split('_')
        c, r = int(c), int(r)
        c_max = max(c_max, c)
        r_max = max(r_max, r)

    lr_img = np.zeros(((r_max+1)*100, (c_max+1)*100, 3), dtype = np.uint8)

    for item in os.listdir(roi_img_dir):
        img_name = item.split('.')
        c, r = img_name[0].split('_')
        c, r = int(c), int(r)

        if c % 2 == 0:
            lr_img[r*100:r*100+100, c*100:c*100+100] = cv2.imread(os.path.join(roi_img_dir, item))
        else:
            lr_img[(r_max-r)*100:(r_max-r)*100+100, c*100:c*100+100] = cv2.imread(os.path.join(roi_img_dir, item))

    return lr_img, r_max, c_max


def cal_global_shift(lr_img, c_max):
    ver_tx = list()

    for i in range(0, c_max):
        r_shift, c_shift, corr = register_tx(lr_img[:, i*100:i*100+100, :], lr_img[:, (i+1)*100:(i+1)*100+100, :])

        if r_shift == 0 and i != 0:
            r_shift = -1*ver_tx[i-1][0]

        ver_tx.append((r_shift, corr))

    glb_trans = optimize_coordinates(ver_tx, c_max)
    glb_trans = np.asarray(glb_trans, dtype=np.int)

    return glb_trans


def create_roi(logger, roi_img_dir, target_img_path):

    lr_img, r_max, c_max = create_unaligned_wsi(roi_img_dir)
    logger.info("Unaligned low resolution wsi array created")

    glb_trans = cal_global_shift(lr_img, c_max)
    logger.info("Global translations calculated among columns on wsi array")

    roi = np.zeros(((r_max+1)*100, (c_max+1)*100, 3))

    for i in range(0, c_max+1):
        if glb_trans[i] < 0:
            roi[0:(r_max+1)*100 - abs(glb_trans[i]), i*100:i*100+100, :] = lr_img[abs(glb_trans[i]):(r_max+1)*100, i*100:i*100+100, :]
        else:
            roi[glb_trans[i]:(r_max+1)*100, i*100:i*100+100, :] = lr_img[0:((r_max+1)*100)-glb_trans[i], i*100:i*100+100, :]

    width = int(roi.shape[1] * 50 / 100)
    height = int(roi.shape[0] * 50 / 100)
    dim = (width, height)

    resized = cv2.resize(roi, dim, interpolation=cv2.INTER_AREA)
    rotated = cv2.rotate(resized, cv2.ROTATE_90_COUNTERCLOCKWISE)

    cv2.imwrite(target_img_path, rotated)

    logger.info("Aligned low resolution wsi image saved")
    return height, width
