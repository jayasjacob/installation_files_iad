import logging
from iad import Iad

logging.basicConfig(filename="/tmp/log.txt", format='%(asctime)s %(message)s', filemode='w')
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

iad = Iad(logger)
logger.info("Successfully init iad")
iad.__start_image_async((4000, 1000), (54, 26), (28, 35), "/home/hari/iad")
iad.join()