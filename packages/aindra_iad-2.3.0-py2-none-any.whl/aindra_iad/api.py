import os
import logging
import traceback
import logging.handlers
from datetime import datetime
from multiprocessing import Process, Queue

import iad

EVENT_INIT_SUCCESSFULL = 0
EVENT_SLIDE_MAP_SUCCESSFULL = 1

OBJECTIVE_0_5NA = 0
OBJECTIVE_0_75NA = 1


def queue_processor(process_queue_in, process_queue_out, process_lock,
                    command_queue_in, command_queue_out, objective_type_NA, quit_event,
                    log_file=None):
    """
    :param process_queue_in:
    :param process_queue_out:
    :param process_lock: lock to pause the processing
    :param command_queue_in:
    :param command_queue_out:
    :param quit_event: Multiprocessing manager quit event
    :param log_file:
    :return: None
    :raises: None

    command_queue_out exception list:
        Iad.SampleSeekError : Unable to find sample to focus. May be solved by a rerun
        RuntimeError: Error encountered during imaging process. A rerun may solve many of these issues
    """

    logger = _create_logger(log_file)
    logger.info("Started IAD queue API")

    # noinspection PyBroadException
    dt_string = datetime.now().strftime("%d-%m-%Y_%H-%M-%S")
    clog_path = log_file + '_' + dt_string + '.clog'
    clog_path = clog_path

    results_queue = Queue()
    exception_queue = Queue()

    try:
        with process_lock:

            p = Process(target=iad.calibrate, args=(exception_queue, objective_type_NA, logger, clog_path))
            p.start()
            p.join()

            if not exception_queue.empty():
                cal_error = exception_queue.get()
                logger.exception("Init failed with exception as {}".format(cal_error))
                raise cal_error

            command_queue_out.put((EVENT_INIT_SUCCESSFULL, True))
            logger.info("Init successful")

    except Exception as e:
        command_queue_out.put((EVENT_INIT_SUCCESSFULL, False, "Restart IAD"))
        tb = traceback.format_exc()
        logger.exception("Exception in initialisation {} with trace back {}".format(e, tb))
        return

    # noinspection PyBroadException
    try:
        while not quit_event.is_set():
            with process_lock:

                process_obj = process_queue_in.get()
                logger.info("Received process object is {}".format(process_obj))

                if process_obj[1] == "ROI":

                    try:
                        target_path = process_obj[0]
                        logger.info("Received for ROI map with target path {}".format(target_path))

                        p = Process(target=iad.map_slide,
                                    args=(target_path, results_queue, exception_queue, objective_type_NA, logger, clog_path))
                        p.start()
                        p.join()

                        if not exception_queue.empty():
                            map_error = exception_queue.get()
                            logger.exception("Map slide failed with exception as {}".format(map_error))
                            raise map_error

                        scale_x, scale_y = results_queue.get()
                        process_queue_out.put((scale_x, scale_y, target_path))

                    except Exception as e:
                        tb = traceback.format_exc()
                        logger.exception(
                            "Exception in RoI creation for slide {} with error {} and traceback {}".format(slide, e,
                                                                                                           tb))
                        process_queue_out.put(RuntimeError(slide.uid))

                elif process_obj[1] == "SCAN":
                    try:
                        slide, roi_coordinates = process_obj[0]
                        logger.info("Received for imaging {} with ROI {}".format(slide.tile_dir, roi_coordinates))

                        p = Process(target=iad.image_slide,
                                    args=(slide.tile_dir, slide.slide_type, roi_coordinates, exception_queue, objective_type_NA, logger,
                                          clog_path))
                        p.start()
                        p.join()

                        with open(os.path.join(slide.tile_dir, "acq_finished.txt"), "w") as f:
                            pass

                        if not exception_queue.empty():
                            acq_error = exception_queue.get()
                            logger.exception("Acquisition failed with exception as {}".format(acq_error))
                            raise acq_error

                        process_queue_out.put(slide)
                        logger.info('Successfully processed {}'.format(slide.tile_dir))

                    except Exception as e:
                        tb = traceback.format_exc()
                        with open(os.path.join(slide.tile_dir, "acq_finished.txt"), "w") as f:
                            pass

                        logger.exception(
                            "Exception in processing for slide {} with error {}  and traceback {}".format(slide, e, tb))
                        process_queue_out.put(RuntimeError(slide.uid))

    except Exception:
        logger.exception("Unable to start IAD")
    logger.info("Iad Queue API exit")


def _create_logger(filename):
    formatter = logging.Formatter('%(asctime)s - %(filename)s: %(levelname)s - %(lineno)d - %(message)s')
    logger_obj = logging.getLogger()
    logger_obj.setLevel(logging.DEBUG)
    fh = logging.handlers.RotatingFileHandler(filename, maxBytes=102400, backupCount=10)
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(formatter)
    logger_obj.addHandler(fh)
    return logger_obj
