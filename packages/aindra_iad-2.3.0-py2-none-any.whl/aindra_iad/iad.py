import os
import shutil
import ctypes
import serial.tools.list_ports
from random import randint

import roi

from aindra_ds import cacx


class SampleSeekError(RuntimeError):
    pass


class CalibrationError(RuntimeError):
    pass


class TrayMoveError(RuntimeError):
    pass


class RoiMapError(RuntimeError):
    pass


class ConnectError(RuntimeError):
    pass


class DisconnectError(RuntimeError):
    pass


def _connect(iad_instance, objective_type_NA, status, signal, logger, clog_path):
    my_path = os.path.abspath(os.path.dirname(__file__))

    lib_path = os.path.join(my_path, "native/bin/libiad.so")
    logger.info("Loading native library at {}".format(lib_path))
    iad_lib = ctypes.cdll.LoadLibrary(lib_path)

    logger.info("Scanning serial ports")
    ports = list(serial.tools.list_ports.comports())
    for port in ports:
        if "FT232R USB UART" == port.description:
            logger.info("Recognized {} as iad".format(port))

            log_file_path = clog_path.encode('utf-8')
            status = iad_lib.iad_connect(port.device, 9600, objective_type_NA,
                                         ctypes.byref(status), ctypes.byref(signal),
                                         log_file_path, ctypes.byref(iad_instance))
            if status != 0:
                raise ConnectError("IAD connection failed")
            return iad_lib
    raise IOError("Unable to find ECU")


def _init(iad_lib, iad_instance):
    iad_lib.iad_init(iad_instance)


def _deinit(iad_lib, iad_instance):
    iad_lib.iad_deinit(iad_instance)


def _disconnect(iad_lib, iad_instance):
    status = iad_lib.iad_disconnect(iad_instance)
    if status != 0:
        raise DisconnectError("IAD disconnection failed")


def _tray_out(iad_lib, iad_instance):
    status = iad_lib.iad_tray_out(iad_instance)
    if status != 0:
        raise TrayMoveError("Tray out movement failed")


def _tray_in(iad_lib, iad_instance):
    status = iad_lib.iad_tray_in(iad_instance)
    if status != 0:
        raise TrayMoveError("Tray in movement failed")


def calibrate(exception_queue, objective_type_NA, logger, clog_path):
    try:
        iad_instance = ctypes.c_void_p()
        status = ctypes.c_float()
        signal = ctypes.c_int()

        iad_lib = _connect(iad_instance, objective_type_NA, status, signal, logger, clog_path)
        _init(iad_lib, iad_instance)

        status = iad_lib.iad_calibrate(iad_instance)
        if status != 0:
            raise CalibrationError("Calibration failed")

        _tray_out(iad_lib, iad_instance)

        _deinit(iad_lib, iad_instance)
        _disconnect(iad_lib, iad_instance)

    except Exception as e:
        exception_queue.put(e)


def map_slide(tgt_path, results_queue, exception_queue, objective_type_NA, logger, clog_path):

    try:
        rand_num = randint(100, 999)
        roi_imgs_dir = os.path.join("/tmp/", str(rand_num), "")
        if os.path.exists(roi_imgs_dir):
            shutil.rmtree(roi_imgs_dir)

        os.makedirs(roi_imgs_dir)
        logger.info("RoI tmp directory created {}".format(roi_imgs_dir))

        iad_instance = ctypes.c_void_p()
        status = ctypes.c_float()
        signal = ctypes.c_int()

        iad_lib = _connect(iad_instance, objective_type_NA, status, signal, logger, clog_path)
        _init(iad_lib, iad_instance)

        i_xtravel, i_ytravel = ctypes.c_int(), ctypes.c_int()
        b_roi_imgs_dir = roi_imgs_dir.encode('utf-8')
        status = iad_lib.iad_map(iad_instance, ctypes.byref(i_xtravel), ctypes.byref(i_ytravel), b_roi_imgs_dir)

        _deinit(iad_lib, iad_instance)
        _disconnect(iad_lib, iad_instance)

        logger.info("roi images acquired")

        height_roi, width_roi = roi.create_roi(logger, roi_imgs_dir, tgt_path)
        logger.info("Low resolution wsi image created")

        shutil.rmtree(roi_imgs_dir)
        logger.info("RoI tmp directory deleted")

        if status == 0:
            results_queue.put((float(i_xtravel.value) / height_roi, float(i_ytravel.value) / width_roi))
        else:
            raise RoiMapError("Roi mapping failed")

    except Exception as e:
        exception_queue.put(e)


def image_slide(tgt_dir, imaging_mode, roi_coordinates, exception_queue, objective_type_NA, logger, clog_path):
    try:
        if roi_coordinates is None:
            if imaging_mode == cacx.SLIDE_TYPE_PAP_HISTO:
                _image_async((1800, 200, 5300, 2200), cacx.SLIDE_TYPE_PAP_HISTO, tgt_dir, objective_type_NA, logger, clog_path)

            elif imaging_mode == cacx.SLIDE_TYPE_PAP_HAEMA:
                _image_async((1800, 200, 5300, 2200), cacx.SLIDE_TYPE_PAP_HAEMA, tgt_dir, objective_type_NA, logger, clog_path)

            elif imaging_mode == cacx.SLIDE_TYPE_PAP_CONV:
                _image_async((1800, 200, 5300, 2200), cacx.SLIDE_TYPE_PAP_CONV, tgt_dir, objective_type_NA, logger, clog_path)

            elif imaging_mode == cacx.SLIDE_TYPE_PAP_LBC:
                _image_async((1900, 200, 4100, 2300), cacx.SLIDE_TYPE_PAP_LBC, tgt_dir, objective_type_NA, logger, clog_path)

            else:
                raise NotImplementedError("The imaging mode {} is not supported".format(imaging_mode))
        else:

            if imaging_mode == cacx.SLIDE_TYPE_PAP_HISTO:
                _image_async(roi_coordinates, cacx.SLIDE_TYPE_PAP_HISTO, tgt_dir, objective_type_NA, logger, clog_path)

            elif imaging_mode == cacx.SLIDE_TYPE_PAP_HAEMA:
                _image_async(roi_coordinates, cacx.SLIDE_TYPE_PAP_HAEMA, tgt_dir, objective_type_NA, logger, clog_path)

            elif imaging_mode == cacx.SLIDE_TYPE_PAP_CONV:
                _image_async(roi_coordinates, cacx.SLIDE_TYPE_PAP_CONV, tgt_dir, objective_type_NA, logger, clog_path)

            elif imaging_mode == cacx.SLIDE_TYPE_PAP_LBC:
                _image_async(roi_coordinates, cacx.SLIDE_TYPE_PAP_LBC, tgt_dir, objective_type_NA, logger, clog_path)

            else:
                raise NotImplementedError("The imaging mode {} is not supported".format(imaging_mode))
    except Exception as e:
        exception_queue.put(e)


def _image_async(roi, imaging_mode, tgt_dir, objective_type_NA, logger, clog_path):
    iad_instance = ctypes.c_void_p()
    status = ctypes.c_float()
    signal = ctypes.c_int()

    status.value = 0
    signal.value = 0

    b_tgt_dir = tgt_dir.encode('utf-8')
    i_img_mode = ctypes.c_int()
    i_img_mode.value = imaging_mode

    iad_lib = _connect(iad_instance, objective_type_NA, status, signal, logger, clog_path)
    _init(iad_lib, iad_instance)

    _tray_in(iad_lib, iad_instance)

    iad_lib.start_image_async.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                          ctypes.c_int, ctypes.c_char_p]

    logger.info("Staring async imaging to {}".format(tgt_dir))
    iad_lib.start_image_async(iad_instance, roi[0], roi[1], roi[2], roi[3], i_img_mode, b_tgt_dir)

    ret = iad_lib.join_image_async(iad_instance)

    _tray_out(iad_lib, iad_instance)

    _deinit(iad_lib, iad_instance)
    _disconnect(iad_lib, iad_instance)

    if ret != 0:
        raise SampleSeekError("Unable to find samples to focus")


def move(x, y, z, logger, clog_path):
    iad_instance = ctypes.c_void_p()
    status = ctypes.c_float()
    signal = ctypes.c_int()

    iad_lib = _connect(iad_instance, status, signal, logger, clog_path)
    status = iad_lib.iad_move(iad_instance, x, y, z)
    _disconnect(iad_lib, iad_instance)

    if status != 0:
        raise TrayMoveError("Tray is not moving")


def home(logger, clog_path):
    iad_instance = ctypes.c_void_p()
    status = ctypes.c_float()
    signal = ctypes.c_int()

    iad_lib = _connect(iad_instance, status, signal, logger, clog_path)
    status = iad_lib.iad_home(iad_instance)
    _disconnect(iad_lib, iad_instance)

    if status != 0:
        raise TrayMoveError("Homing is not moving")
