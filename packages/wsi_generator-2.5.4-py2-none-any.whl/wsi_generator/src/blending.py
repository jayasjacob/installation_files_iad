import os
import numpy as np
import ctypes

my_path = os.path.abspath(os.path.dirname(__file__))
lib_path = os.path.join(my_path, "blend/bin/libblend.so")
blend_lib = ctypes.cdll.LoadLibrary(lib_path)
alpha_mask_ptr = ctypes.c_void_p(0)


def create_clogger(clogfile_path):
    log_path = clogfile_path.encode('utf-8')
    blend_lib.initialize_logger(log_path)


def remove_clogger():
    blend_lib.remove_logger()


def create_mask(img_height, img_width):
    status = blend_lib.create_alpha_mask(img_height, img_width, ctypes.byref(alpha_mask_ptr))
    if status != 0:
        raise RuntimeError("Blend mask creation failed")


class BlendData:

    def __init__(self):
        self.__blend_lib = blend_lib

    def __enter__(self):
        self.blend_data_ptr = ctypes.c_void_p(0)
        self.__blend_lib.allocate(ctypes.byref(self.blend_data_ptr))
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        self.__blend_lib.deallocate(self.blend_data_ptr)
        return self

    def append(self, image_path, img_tl_rel_pos_0, img_tl_rel_pos_1, img_br_rel_pos_0, img_br_rel_pos_1,
               tile_tl_rel_pos_0, tile_tl_rel_pos_1, tile_br_rel_pos_0, tile_br_rel_pos_1):
        status = self.__blend_lib.append(ctypes.byref(self.blend_data_ptr), image_path,
                                         img_tl_rel_pos_0, img_tl_rel_pos_1,
                                         img_br_rel_pos_0, img_br_rel_pos_1,
                                         tile_tl_rel_pos_0, tile_tl_rel_pos_1,
                                         tile_br_rel_pos_0, tile_br_rel_pos_1)
        return status


def compute_blending_grid(src_list, tgt_tile_size, tgt_overlap):
    tgt_tile_size = np.asarray(tgt_tile_size, dtype=float)

    # Compute the source images, that overlaps with a specified target image
    blend_dict = dict()
    cmax, rmax = 0, 0
    wsi_br_idx = np.asarray([0, 0])

    for item in src_list:
        # ********************** Extent of an image *************************************
        # The deep zoom tiles are structured like this
        # overlap - tile size - overlap
        # for images at the edges the overlap may not be present.
        #
        # Let o be the target overlap
        # Let s be the target size
        # Let s' be the source size
        #
        # Hence the limits on images are
        # 0------s-----o
        # -------------o---s---o
        # ---------------------o---s---o
        # ----------------------------o---s---o
        # Hence each image will span
        # -----0--------
        #      ----------1-------
        #                        --------2--------
        # ie the extent of an image is from
        # 0-------------- 0 ---------- s+o
        # 1-------------s ---------- 2s+2o
        # 2-------------2s+o----------3s+3o
        # 3-------------3s+2o----------4s+4o
        # ns+(n-1)o --------------------(o+s)(n+1)
        # *********************************************************************************
        # Let us find the tiles onto which a src image will fall.
        # -----------------------Top left---------------------------------------------
        # Let TL of tile be p1
        # Then we need to find the first tile whose end is after the pixel
        # All other tiles to the right will be inside the image then
        # ie we need the smallest n for which end > p
        # (o+s)(n+1) > p1
        # n > (p1)/(o+s) - 1
        # ie the smallest n for which above eq is satisfied
        # ie n = ceil((p1)/(o+s) - 1)
        #
        # So the loop will start from n = ceil((p1)/(o+s) - 1)
        # --------------------------------------------------------------------
        # Let BR of tile be p2
        # Then we need to find the last tile which starts before BR
        # Then all the tiles before it will be a part of the image
        # ns+(n-1)o < p2
        # n < (p2+o)/(o+s)
        # n = floor((p2 + o)/(o+s))

        image_name, image_tl_pos, image_size = item

        # -----------------------------------------------------------------------------------------------------
        # If src_scale == 1.0, it means that we are not going to downscale pyramid
        # if src_scale == 0.5 it means we will downscale pyramid by half wrt src images
        # There are two ways to achieve this.
        # 1. Generate the current layer without downscale but assume tile sizes and overlap are double
        #    Then while saving the tile, downscale it by half and save.
        #    The problem with this approach is that the blending grid will not be
        # 2. While computing the grid, assume that the src coordinates are half, src images are half.
        #    While blending downscale images by half.
        # -----------------------------------------------------------------------------------------------------
        image_tl_pos = np.asarray(image_tl_pos, dtype=float)
        image_size = np.asarray(image_size, dtype=float)
        image_size = np.clip(image_size, a_min=1.0, a_max=None)
        image_size = np.ceil(image_size)
        image_size = np.asarray(image_size, dtype=np.int)

        # extent of an image is from
        # (2o+s)n-o -- (2o+s)n -- (2o+s)n+o -- (2o+s)(n+1)-o -- (2o+s)(n+1) --(2o+s)(n+1)+o

        tl_tile = image_tl_pos / (tgt_tile_size + tgt_overlap) - 1

        br_tile = (image_tl_pos + image_size + tgt_overlap) / (tgt_tile_size + tgt_overlap)
        br_tile = np.clip(br_tile, a_min=0, a_max=None)

        # FIXME : Why is this right? understand and document

        tl_tile = np.ceil(tl_tile)
        tl_tile = np.clip(tl_tile, a_max=None, a_min=0)
        br_tile = np.floor(br_tile)

        # Add the current image to all the target images that it falls on to

        tl_tile = np.asarray(tl_tile, dtype=int)
        br_tile = np.asarray(br_tile, dtype=int)

        for r in range(tl_tile[0], br_tile[0] + 1):
            for c in range(tl_tile[1], br_tile[1] + 1):

                if '{}_{}'.format(r, c) not in blend_dict:
                    blend_dict['{}_{}'.format(r, c)] = list()

                tile_id = np.asarray([r, c])

                tile_tl_pos = (tgt_tile_size + tgt_overlap) * tile_id - tgt_overlap
                tile_tl_pos = np.clip(tile_tl_pos, a_min=0, a_max=None)  # For tile zero
                tile_br_pos = (tgt_tile_size + tgt_overlap) * (tile_id + 1)

                # Position of image in global coordinates
                # image_tl_pos = image_tl_pos
                image_br_pos = image_tl_pos + image_size

                # Maximum size of WSI
                wsi_br_idx = np.maximum(wsi_br_idx, image_br_pos)

                # Position or image tl in local tile_coordinates
                img_tl_rel_pos = np.clip(tile_tl_pos - image_tl_pos, a_min=0, a_max=None)
                img_br_rel_pos = np.clip(tile_br_pos - image_tl_pos, a_min=None, a_max=image_size)

                # Position of tile in local image coordinates
                tile_tl_rel_pos = np.clip(image_tl_pos - tile_tl_pos, a_min=0, a_max=None)
                tile_bounds = tgt_tile_size + tgt_overlap
                tile_bounds[tile_id > 0] += tgt_overlap
                tile_br_rel_pos = np.clip(image_br_pos - tile_tl_pos, a_min=None, a_max=tile_bounds)

                blend_dict['{}_{}'.format(r, c)].append([image_name,
                                                         np.asarray(img_tl_rel_pos, dtype=int),
                                                         np.asarray(img_br_rel_pos, dtype=int),
                                                         np.asarray(tile_tl_rel_pos, dtype=int),
                                                         np.asarray(tile_br_rel_pos, dtype=int)])
                cmax = max(cmax, c)
                rmax = max(rmax, r)

    blend_list = []

    wsi_br_idx = np.asarray(wsi_br_idx, dtype=np.float)
    wsi_br_idx = np.ceil(wsi_br_idx / 2) * 2
    wsi_br_idx = np.asarray(wsi_br_idx, dtype=np.int)

    for c in range(cmax + 1):
        for r in range(rmax + 1):

            key = "{}_{}".format(r, c)

            if key in blend_dict:

                tile_id = np.asarray([int(r), int(c)])

                tile_tl_pos = (tgt_tile_size + tgt_overlap) * tile_id - tgt_overlap
                tile_tl_pos = np.clip(tile_tl_pos, a_min=0, a_max=None)

                tile_bounds = tgt_tile_size.copy()
                tile_bounds[tile_id > 0] += tgt_overlap
                is_end = np.less(tile_id, np.asarray([rmax, cmax]))
                tile_bounds[is_end] += tgt_overlap

                wsi_bounds = wsi_br_idx - tile_tl_pos

                tile_bounds[wsi_bounds < tile_bounds] = wsi_bounds[wsi_bounds < tile_bounds]
                tile_bounds = np.clip(tile_bounds, a_min=tgt_overlap, a_max=None)

                blend_items = blend_dict[key]
                blend_list.append([tile_id, tile_tl_pos, tile_bounds, blend_items])

            else:
                tile_id = np.asarray([int(r), int(c)])

                tile_tl_pos = (tgt_tile_size + tgt_overlap) * tile_id - tgt_overlap
                tile_tl_pos = np.clip(tile_tl_pos, a_min=0, a_max=None)  # For tile zero

                tile_bounds = tgt_tile_size.copy()
                tile_bounds[tile_id > 0] += tgt_overlap
                tile_bounds[tile_id < np.array([rmax, cmax])] += tgt_overlap

                wsi_bounds = wsi_br_idx - tile_tl_pos

                tile_bounds[wsi_bounds < tile_bounds] = wsi_bounds[wsi_bounds < tile_bounds]
                tile_bounds = np.clip(tile_bounds, a_min=tgt_overlap, a_max=None)

                blend_items = [None, None, None, None, None, None]
                blend_list.append([tile_id, tile_tl_pos, tile_bounds, blend_items])

    return blend_list, wsi_br_idx


def blend_worker(aug_blend_queue, exception_queue):
    while True:
        task = aug_blend_queue.get()
        if task is None:
            aug_blend_queue.put(None)
            return
        else:
            blend_item, dir_path, is_alpha_blending, scale = task
            f_scale = ctypes.c_float()
            f_scale.value = scale

            target_img_id, _, blend_size, blend_images = blend_item
            target_img_path = os.path.join(dir_path, '{}_{}.webp'.format(target_img_id[1], target_img_id[0]))

            tile_shape = np.asarray(blend_size, dtype=int)

            status = 0
            if blend_images[0] is not None:
                with BlendData() as blend_data:
                    for item in blend_images:
                        image_path, img_tl_rel_pos, img_br_rel_pos, tile_tl_rel_pos, tile_br_rel_pos = item

                        image_path = image_path.encode('utf-8')
                        status += blend_data.append(image_path,
                                                    img_tl_rel_pos[0], img_tl_rel_pos[1],
                                                    img_br_rel_pos[0], img_br_rel_pos[1],
                                                    tile_tl_rel_pos[0], tile_tl_rel_pos[1],
                                                    tile_br_rel_pos[0], tile_br_rel_pos[1])

                    if is_alpha_blending:
                        status += blend_lib.save_alpha_blended_image(blend_data.blend_data_ptr, alpha_mask_ptr,
                                                                     target_img_path.encode('utf-8'), f_scale,
                                                                     tile_shape[0], tile_shape[1])
                    else:
                        status += blend_lib.save_avg_blended_image(blend_data.blend_data_ptr,
                                                                   target_img_path.encode('utf-8'),
                                                                   f_scale, tile_shape[0], tile_shape[1])

            else:
                status += blend_lib.save_blank_image(target_img_path.encode('utf-8'), f_scale, tile_shape[0],
                                                     tile_shape[1])

            if status != 0:
                exception_queue.put(("Failed", task))
                # raise RuntimeError("Blend image and save failed")
