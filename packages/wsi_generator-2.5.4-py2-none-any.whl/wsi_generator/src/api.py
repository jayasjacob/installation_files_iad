import os
import time

import traceback

import logging
import logging.handlers
from datetime import datetime

from wsiconfig import *
import stitch as stitcher


def queue_processor(process_queue_in, process_queue_out, process_lock, quit_event, log_file):
    logger = _create_logger(log_file)

    dt_string = datetime.now().strftime("%d-%m-%Y_%H-%M-%S")
    clog_path = log_file + '_' + dt_string + '.clog'

    logger.info("Starting stitching queue API")

    while not quit_event.is_set():
        slide = process_queue_in.get()
        logger.info("Received for stitching {}, {}".format(slide.tile_dir, slide.pyramid_dir))

        # noinspection PyBroadException
        try:
            tic = time.time()
            logger.info('Performing stitching on {}'.format(slide.tile_dir, time.time() - tic))
            if DUMMY:
                logger.info('Dummy Image Processing.....')
            else:
                stitcher.stitch_slide(slide.slide_dir, slide.tile_dir, slide.pyramid_dir, logger, clog_path,
                                      process_lock)
            logger.info('Successfully processed {} in {}s'.format(slide.pyramid_dir, time.time() - tic))
            process_queue_out.put(slide)

        except Exception as e:
            tb = traceback.format_exc()
            logger.exception("Exception in stitching {} with trace back {}".format(e, tb))
            logger.exception("Exception in stitching {}".format(e))
            process_queue_out.put(RuntimeError(slide.uid))


def _create_logger(filename):
    formatter = logging.Formatter('%(asctime)s - %(filename)s: %(levelname)s - %(lineno)d - %(message)s')
    logger_obj = logging.getLogger()
    logger_obj.setLevel(logging.DEBUG)
    fh = logging.handlers.RotatingFileHandler(filename, maxBytes=102400, backupCount=10)
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(formatter)
    logger_obj.addHandler(fh)
    return logger_obj
