import logging
from multiprocessing import Queue, Lock, Process
import multiprocessing

from src import api
from aindra_ds.cacx import Slide
from aindra_ds import cacx

process_queue_in, process_queue_out = Queue(), Queue()

manager = multiprocessing.Manager()
process_lock = manager.Lock()
quit_event = manager.Event()

log_file = "/home/aindra/abhay/stitch_algo_log.log"

p = Process(target=api.queue_processor, args=(process_queue_in, process_queue_out, process_lock, quit_event, log_file))
p.start()

# start process with supplying source dir and pyramid dir

img_job = Slide(slide_dir="/home/aindra/abhay/50_HCG14-14/", tile_dir="/home/aindra/abhay/50_HCG14-14/tiles/",
                slide_type=cacx.SLIDE_TYPE_PAP_HISTO)

process_queue_in.put(img_job)

p.join()
