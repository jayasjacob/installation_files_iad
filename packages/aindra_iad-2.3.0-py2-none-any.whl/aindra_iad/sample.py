from multiprocessing import Process, Queue, Lock
import multiprocessing

from aindra_iad import api
from aindra_ds import cacx


process_queue_in, process_queue_out = Queue(), Queue()
command_queue_in, command_queue_out = Queue(), Queue()
process_lock = Lock()

manager = multiprocessing.Manager()
quit_event = manager.Event()

# Start the imaging in a separate process
log_file = '/tmp/acq.log'
p = Process(target=api.queue_processor, args=(process_queue_in, process_queue_out, process_lock,
                                              command_queue_in, command_queue_out, api.OBJECTIVE_0_75NA, quit_event,
                                              log_file))
p.start()

# Create a job
# Note that we need at least the slide_info_file where the parameters will be saved and
# tile_dir where the images will be stored

img_job = cacx.Slide(slide_dir="/tmp/iad/lbc_slide", tile_dir="/tmp/iad/lbc_slide", slide_type=cacx.SLIDE_TYPE_PAP_HAEMA)
# process_queue_in.put(("/tmp/roi.jpg", "ROI"))

process_queue_in.put(((img_job, None), "SCAN"))

# Finally StopIteration need to be put in the queue so that the procesing is stopped gracefully
process_queue_in.put(StopIteration)
p.join()
